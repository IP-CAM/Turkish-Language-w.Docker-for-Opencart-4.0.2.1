<?php
// Heading
$_['heading_title'] = 'Raporlar';

// Text
$_['text_success']  = 'Başarılı: Raporlar başarılı bir şekilde değiştirildi!';
$_['text_type']     = 'Rapor Türünü Seçin';
$_['text_filter']   = 'Filtrele';