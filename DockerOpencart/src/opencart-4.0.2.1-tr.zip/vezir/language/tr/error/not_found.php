<?php


// Heading
$_['heading_title']  = 'Aradığınız Sayfa Bulunamadı!';

// Text
$_['text_not_found'] = 'Aradığınız sayfa bulunamadı! Eğer sorun devam ederse lütfen yöneticiniz ile irtibata geçiniz';