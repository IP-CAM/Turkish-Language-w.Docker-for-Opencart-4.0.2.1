<?php


// Text
$_['text_subject']   = '%s - GDPR İsteğiniz Uygulandı!';
$_['text_request']   = 'Hesap Silme İsteği';
$_['text_hello']     = 'Merhaba <strong>%s</strong>,';
$_['text_user']      = 'Kullanıcı';
$_['text_delete']    = 'GDPR veri silme isteğiniz tamamlandı.';
$_['text_contact']   = 'Daha fazla bilgi için buradan mağazaya ulaşabilirsiniz:';
$_['text_thanks']    = 'Teşekkürler,';

// Button
$_['button_contact'] = 'İletişime Geçin';