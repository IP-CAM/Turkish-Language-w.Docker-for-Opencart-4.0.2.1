<?php


// Text
$_['text_subject']  = '%s - Ortaklık Hesabınız Etkinleştirildi!';
$_['text_welcome']  = '%s ortaklık programına kayıt olduğunuz için teşekkür ederiz!';
$_['text_login']    = 'Ortaklık hesabınız onaylanmıştır. Aşağıdaki adres üzerinden, sitemize kayıtlı e-posta ve şifrenizi kullanarak giriş yapabilirsiniz:';
$_['text_service']  = 'Oturum açtıktan sonra, takip kodu oluşturabilir, kazançlarınızı takip edebilir ve bilgilerinizi düzenleyebilirsiniz.';
$_['text_thanks']   = 'Teşekküler,';