<?php


// Text
$_['text_success']  = 'Başarılı: Hediye çeki başarılı bir şekilde değiştirildi!';
$_['text_subject']  = '%s tarafından hediye çeki gönderildi!';
$_['text_greeting'] = 'Tebrikler, %s değerinde bir hediye çeki aldınız';
$_['text_from']     = 'Bu hediye çeki %s tarafından gönderildi';
$_['text_message']  = 'Birde mesajınız var';
$_['text_redeem']   = 'Aşağıdaki bağlantıdaki web sitesine giderek istediğiniz ürünü sepete ekleyiniz ve <b>kasaya gitmenden</b> önce <b>alışveriş sepeti</b> sayfasında size gönderilen hediye çeki kodu <b>%s</b> girerek kullanabilirsiniz.';
$_['text_footer']   = 'Lütfen herhangi bir sorunuz varsa bu e-posta adresini yanıtlayınız.';
$_['text_sent']     = 'Başarılı: Hediye çeki e-postası gönderildi!';
