<?php
// Text
$_['text_subject'] = 'Güvenlik kodu denemelerini sıfırla';
$_['text_reset']   = 'Birisi güvenlik kodunu 3 defadan fazla yanlış girmiş.';
$_['text_link']    = 'Hesap güvenliğini sıfırlamak için aşağıdaki bağlantıya tıklayın:';
$_['text_ip']      = 'IP Adresi:';
$_['text_regards'] = 'Saygılarımızla';