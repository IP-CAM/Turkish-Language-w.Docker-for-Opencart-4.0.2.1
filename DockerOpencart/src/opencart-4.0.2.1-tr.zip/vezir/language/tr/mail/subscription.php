<?php


// Text
$_['text_subject']             = '%s - Abonelik';
$_['text_subscription_id']     = 'Abonelik No';
$_['text_date_added']          = 'Abonelik Tarihi:';
$_['text_subscription_status'] = 'Aboneliğiniz aşağıdaki duruma eklendi:';
$_['text_comment']             = 'Aboneliğiniz için yapılan yorumlar';
$_['text_payment_method']      = 'Ödeme Metotu';
$_['text_payment_code']        = 'Ödeme Kodu';
$_['text_footer']              = 'Sorularınız varsa lütfen bu e-postayı yanıtlayın.';
