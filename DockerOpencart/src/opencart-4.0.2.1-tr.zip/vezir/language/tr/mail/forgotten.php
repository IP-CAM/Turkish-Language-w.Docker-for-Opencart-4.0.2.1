<?php


// Text
$_['text_subject']  = '%s - Parola sıfırlama isteği';
$_['text_greeting'] = '%s yönetici hesabınız için parola sıfırlama talebinde bulundunuz.';
$_['text_change']   = 'Parolanızı sıfırlamak için aşağıdaki bağlantıya tıklayın:';
$_['text_ip']       = 'Parola sıfırlama isteğini yapan IP adresi:';