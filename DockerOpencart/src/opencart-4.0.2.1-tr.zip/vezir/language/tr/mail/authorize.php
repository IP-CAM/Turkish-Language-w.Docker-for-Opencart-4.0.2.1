<?php
// Text
$_['text_subject'] = 'Güvenlik';
$_['text_code']    = 'Yönetici güvenlik kodunu girmeniz gerekir.';
$_['text_ip']      = 'IP Adresi:';
$_['text_regards'] = 'Saygılarımızla';