<?php
// Text
$_['text_recommended'] = 'Önerilen';
$_['text_install']     = 'Kur';
$_['text_uninstall']   = 'Kaldır';
$_['text_delete']      = 'Sil';