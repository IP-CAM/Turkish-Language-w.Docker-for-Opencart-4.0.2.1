<?php


// Heading
$_['heading_title'] = 'Eklentiler';

// Text
$_['text_success']  = 'Başarılı: Eklentiler başarılı bir şekilde değiştirildi!';
$_['text_list']     = 'Eklenti Listesi';
$_['text_type']     = 'Eklenti Türünü Seçin';
$_['text_filter']   = 'Filtrele';