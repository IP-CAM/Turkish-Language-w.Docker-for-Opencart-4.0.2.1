<?php
// Heading
$_['heading_title']    = 'Diller';

// Text
$_['text_success']     = 'Başarılı: Diller başarılı bir şekilde değiştirildi!';
$_['text_list']        = 'Dil Listesi';

// Column
$_['column_name']      = 'Dil Adı';
$_['column_status']    = 'Durumu';
$_['column_action']    = 'Eylem';

// Error
$_['error_permission'] = 'Uyarı: Dilleri düzenleme iznine sahip değilsiniz!';
$_['error_extension']  = 'Uyarı: Eklenti mevcut değil!';