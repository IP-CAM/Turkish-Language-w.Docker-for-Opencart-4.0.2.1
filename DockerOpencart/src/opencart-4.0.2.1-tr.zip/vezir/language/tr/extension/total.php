<?php


// Heading
$_['heading_title']     = 'Sipariş Toplamları';

// Text
$_['text_success']      = 'Başarılı: Sipariş toplamları güncellendi!';

// Column
$_['column_name']       = 'Sipariş Toplamları';
$_['column_status']     = 'Durumu';
$_['column_sort_order'] = 'Sıralama';
$_['column_action']     = 'Eylem';
// Error
$_['error_permission']  = 'Uyarı: Sipariş Toplamlarını değiştirme iznine sahip değilsiniz!';
$_['error_extension']   = 'Uyarı: Eklenti mevcut değil!';