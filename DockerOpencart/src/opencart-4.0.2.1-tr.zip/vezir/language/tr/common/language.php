<?php
$_['error_language'] = 'Uyarı: Dil bulunamadı!';