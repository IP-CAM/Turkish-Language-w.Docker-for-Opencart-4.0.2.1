<?php


// Text
$_['text_footer']  = 'by <a href="https://miajupiter.com" title="MiaJupiter" target="_blank">MiaJupiter</a> &copy;' . date('Y') . ' Tüm Hakları Saklıdır.';
$_['text_version'] = 'Sürüm %s';