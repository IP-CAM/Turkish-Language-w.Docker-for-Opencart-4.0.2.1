<?php
// Text
$_['text_project']       = 'Project Homepage';
$_['text_documentation'] = 'Documentation';
$_['text_support']       = 'Support Forums';
$_['text_footer']        = '<a href="https://miajupiter.com" _target="blank" >dockerized by MiaJupiter</a> &copy;' . date('Y') . ' All Rights Reserved.';