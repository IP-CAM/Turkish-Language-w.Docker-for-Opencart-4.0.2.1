<?php
// Text
$_['text_name']       = 'English (United Kingdom)';
$_['text_loading']    = 'Loading...';

// Button
$_['button_continue'] = 'Continue';
$_['button_back']     = 'Back';

// Error
$_['error_exception'] = 'Error Code(%s): %s in %s on line %s';