<?php


// Heading
$_['heading_title'] = 'İstediğiniz sayfa bulunamadı!';

// Text
$_['text_error']    = 'İstediğiniz sayfa bulunamadı.';