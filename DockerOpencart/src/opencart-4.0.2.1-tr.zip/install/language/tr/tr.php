<?php


// Text
$_['text_name']       = 'Türkçe (Türkiye)';
$_['text_loading']    = 'Yükleniyor...';

// Button
$_['button_continue'] = 'Devam Et';
$_['button_back']     = 'Geri';

// Error
$_['error_exception'] = 'Hata Kodu(%s): %s in %s on line %s';