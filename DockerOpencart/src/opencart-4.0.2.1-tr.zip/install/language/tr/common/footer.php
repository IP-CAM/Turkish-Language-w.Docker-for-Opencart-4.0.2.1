<?php


// Text
$_['text_project']       = 'Proje Anasayfa';
$_['text_documentation'] = 'Dökümanlar';
$_['text_support']       = 'Destek Forumları';
$_['text_footer']        = '<a href="https://miajupiter.com" _target="blank" >dockerized by MiaJupiter</a> &copy;' . date('Y') . ' Tüm hakları saklıdır.';